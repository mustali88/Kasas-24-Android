# KASAS 24 Android build source

This package wraps the existing KASAS 24 web app in Capacitor and uses Android local notifications.

## GitHub upload (phone-friendly)
1. Extract this ZIP.
2. Upload the CONTENTS of this folder into the root of the existing `Kasas-24` repository, preserving `www/` and `.github/workflows/`.
3. Commit to `main`. GitHub Actions starts automatically.
4. In the repository, open Actions → Build KASAS 24 Android APK → latest successful run → Artifacts → KASAS-24-debug-apk.
5. Download and install `app-debug.apk`.
6. On first launch, use Settings → Bildirim izni ver. Restore your JSON backup from the app's Yedek yükle button.

IMPORTANT: The APK uses a separate Android app storage area from the browser PWA. Restore your JSON backup after installation. Do not delete the old PWA or its data until the APK is tested.

This is a debug APK for testing, not a Play Store release. Verify notifications on the actual Xiaomi device, including with the app closed and after reboot. Android battery restrictions / exact-alarm permission can affect delivery.
